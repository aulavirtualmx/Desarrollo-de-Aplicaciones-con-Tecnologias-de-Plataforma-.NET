﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using Diplomado.Models;

namespace Diplomado.Controllers
{
    public class ClientesController : Controller
    {
        Datos db = new Datos();
    
        //
        // GET: /Clientes/
        public ActionResult Index()
        {
            //Lista de clientes 
            List<Cliente> clientes = db.TablaClientes.ToList();
            return View(clientes);
        }

        //
        // GET: /Clientes/Details/5
        public ActionResult Details(int id)
        {
            return View(db.TablaClientes.Find(id));
        }

        //
        // GET: /Clientes/Create
        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Clientes/Create
        [HttpPost]
        public ActionResult Create(Cliente cliente)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    //Buscar si existe el cliente
                    Cliente buscar = db.TablaClientes.Find(cliente.IdCliente);
                    if (buscar == null) //Si no lo encuentra en la bd
                    {
                        //Guardar en base de datos
                        db.TablaClientes.Add(cliente);
                        db.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewBag.error = "Error, al guardar el registro. ID duplicado";
                    }
                }
                
                return View();
                
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Clientes/Edit/5
        public ActionResult Edit(int id)
        {
            return View(db.TablaClientes.Find(id));
        }

        //
        // POST: /Clientes/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Cliente cliente)
        {
            try
            {
                // TODO: Add update logic here
                if (ModelState.IsValid)
                {
                    db.Entry(cliente).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Clientes/Delete/5
        public ActionResult Delete(int id)
        {
            return View(db.TablaClientes.Find(id));
        }

        //
        // POST: /Clientes/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, Cliente cliente)
        {
            try
            {
                // Eliminar en la base de datos
                Cliente buscar = db.TablaClientes.Find(id);
                db.TablaClientes.Remove(buscar);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        private List<Cliente> obtenerClientes()
        {
            List<Cliente> clientes = new List<Cliente>();
            clientes.Add(new Cliente(123, "José", "Conocido 1", "6677112233", "jose@correo.com", new DateTime(2017,1,1)));
            clientes.Add(new Cliente(124, "Juan", "Conocido 2", "6677112244", "juan@correo.com",  new DateTime(2017,1,1)));
            clientes.Add(new Cliente(125, "María", "Conocido 3", "6677112255", "maria@correo.com", new DateTime(2017,1,1)));
            clientes.Add(new Cliente(126, "Lorena", "Conocido 4", "6677112266", "lorena@correo.com", new DateTime(2017, 1, 1)));
            clientes.Add(new Cliente(127, "Jesús", "Conocido 5", "6677112277", "jesus@correo.com", new DateTime(2017, 1, 1)));
            clientes.Add(new Cliente(128, "Pedro", "Conocido 6", "6677112288", "pedro@correo.com", new DateTime(2017, 1, 1)));
            clientes.Add(new Cliente(129, "Laura", "Conocido 7", "6677112299", "laura@correo.com", new DateTime(2017, 1, 1)));
            return clientes;
        }

    }
}
