﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Diplomado.Models
{
    [Table("VentaDetalle")]
    public class VentaDetalle
    {
        [Column(Order = 0), Key]
        public  int NumVenta { get; set; }
        [Column(Order = 1), Key]
        public int IdProd { get; set; }
        public decimal Cantidad { get; set; }
        public decimal PrecioVenta { get; set; }
    }
}