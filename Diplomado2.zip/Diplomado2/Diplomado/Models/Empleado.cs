﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Diplomado.Models
{
    [Table("Empleados")]
    public class Empleado
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Range(100, 9999,
            ErrorMessage = "Debe proporcionar un número entre 100 y 9999")]
        [DisplayName("ID")]
        public int IdEmp { get; set; }
        [DisplayName("Nombre")]
        [Required(ErrorMessage = "Debe proporcionar un nombre")]
        [StringLength(60, MinimumLength = 7,
            ErrorMessage = "Debe de proporcionar al menos 7 letras y máximo 60 letras")]
        public string NomEmp { get; set; }
        [DisplayName("Domicilio")]
        [Required(ErrorMessage = "Debe proporcionar un domicilio")]
        [StringLength(150, MinimumLength = 10,
            ErrorMessage = "Debe de proporcionar al menos 10 caracteres y máximo 150 caracteres")]
        public string DomEmp { get; set; }
        [DisplayName("Celular")]
        [Required(ErrorMessage = "Debe proporcionar un celular")]
        [RegularExpression(@"^(\d{10})$",
            ErrorMessage = "Formato de celular incorrecto")]
        public string CelEmp { get; set; }
        [DisplayName("Correo")]
        [Required(ErrorMessage = "Debe proporcionar un correo")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "El formato del correo electrónico es incorrecto")]
        public string Email { get; set; }
    }
}