﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.Entity;

namespace Diplomado.Models
{
    public class Datos : DbContext
    {
        public Datos()
            : base("DiplomadoBD")
        {

        }

        public DbSet<Cliente> TablaClientes { get; set; }
        public DbSet<Empleado> TablaEmpleados { get; set; }
        public DbSet<Producto> TablaProductos { get; set; }
        public DbSet<Venta> TablaVentas { get; set; }
        public DbSet<UsuarioSeguridad> TablaUsuarios { get; set; }

    }
}