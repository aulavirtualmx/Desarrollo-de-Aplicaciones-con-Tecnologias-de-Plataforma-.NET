﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Diplomado.Models
{
    [Table("Usuarios")]
    public class UsuarioSeguridad
    {
        [Key]
        public int Id { get; set; }
        public string Usuario { get; set; }
        public string Contraseña { get; set; }
        public string Nombre { get; set; }
        public string Estatus { get; set; }
        public string Roles { get; set; }
    }
}