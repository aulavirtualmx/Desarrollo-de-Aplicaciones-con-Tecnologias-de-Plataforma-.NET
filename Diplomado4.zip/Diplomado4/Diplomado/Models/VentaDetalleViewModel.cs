﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Diplomado.Models
{
    public class VentaDetalleViewModel
    {
        public int IdProd { get; set; }
        public int Cantidad { get; set; }
        public decimal PrecioUnitario{ get; set; }
        public decimal TotalProducto { get; set; }
        public string Descripcion { get; set; }
        
    }
}