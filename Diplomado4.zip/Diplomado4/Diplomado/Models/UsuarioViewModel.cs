﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Diplomado.Models
{
    public class UsuarioViewModel
    {
        [Required]
        [Display(Name = "Nombre de usuario")]
        public string Usuario { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "El número de caracteres de {0} debe ser al menos {2}.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Contraseña")]
        public string Contraseña { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirmar contraseña")]
        [Compare("Contraseña", ErrorMessage = "La contraseña y la contraseña de confirmación no coinciden.")]
        public string ConfirmarContraseña { get; set; }

        [Required]
        [Display(Name = "Nombre")]
        [StringLength(100, ErrorMessage = "El número de caracteres de {0} debe ser al menos {2}.", MinimumLength = 6)]
        public string Nombre { get; set; }

        [Required]
        [Display(Name = "Roles")]
        public string Roles { get; set; }
        public List<string> ListadoRoles { get; set; }

        public UsuarioViewModel()
        {
            this.ListadoRoles = new List<string>();
        }
    }
}