﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace Diplomado.Models
{

    public class LoginViewModel
    {
        [Required]
        [Display(Name = "Usuario")]
        public string Usuario { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Contraseña")]
        public string Contraseña { get; set; }

       
    }

   
}
