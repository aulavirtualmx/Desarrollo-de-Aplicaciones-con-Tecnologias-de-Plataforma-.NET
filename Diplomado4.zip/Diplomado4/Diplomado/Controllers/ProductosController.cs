﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using Diplomado.Models;

namespace Diplomado.Controllers
{
     [Authorize(Roles = "admin, captura")]
    public class ProductosController : Controller
    {
        Datos db = new Datos();

        // GET: Productos
        public ActionResult Index()
        {
            return View(db.TablaProductos.ToList());
        }

        // GET: Productos/Details/5
        public ActionResult Details(int id)
        {
            return View(db.TablaProductos.Find(id));
        }

        // GET: Productos/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Productos/Create
        [HttpPost]
        public ActionResult Create(Producto producto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    //Buscar si existe el empleado
                    Producto buscar = db.TablaProductos.Find(producto.IdProd);
                    if (buscar == null) //Si no lo encuentra en la bd
                    {
                        //Guardar en base de datos
                        db.TablaProductos.Add(producto);
                        db.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewBag.error = "Error, al guardar el registro. ID duplicado";
                    }
                }

                return View();

            }
            catch
            {
                return View();
            }
        }

        // GET: Productos/Edit/5
        public ActionResult Edit(int id)
        {
            return View(db.TablaProductos.Find(id));
        }

        // POST: Productos/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Producto producto)
        {
            try
            {
                // TODO: Add update logic here
                if (ModelState.IsValid)
                {
                    db.Entry(producto).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        // GET: Productos/Delete/5
        public ActionResult Delete(int id)
        {
            return View(db.TablaProductos.Find(id));
        }

        // POST: Productos/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, Producto producto)
        {
            try
            {
                // Eliminar en la base de datos
                Producto buscar = db.TablaProductos.Find(id);
                db.TablaProductos.Remove(buscar);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
