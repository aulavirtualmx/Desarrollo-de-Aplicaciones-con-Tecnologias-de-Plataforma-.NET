﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin.Security;
using Diplomado.Models;



using System.Web.Security;

namespace Diplomado.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        Datos db = new Datos();


        //
        // GET: /Account/Login
        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        //
        // POST: /Account/Login
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginViewModel model, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                
                UsuarioSeguridad usuario = db.Database.SqlQuery<UsuarioSeguridad>("ValidarUsuario @Usuario,@Contraseña",
                    new System.Data.SqlClient.SqlParameter("@Usuario",model.Usuario), 
                    new System.Data.SqlClient.SqlParameter("@Contraseña",model.Contraseña)).FirstOrDefault();

                if (usuario != null)
                {
                    FormsAuthentication.SetAuthCookie(usuario.Usuario, false);

                    var authTicket = new FormsAuthenticationTicket(1, usuario.Usuario, DateTime.Now, DateTime.Now.AddMinutes(20), false, usuario.Roles);
                    string encryptedTicket = FormsAuthentication.Encrypt(authTicket);
                    var authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
                    HttpContext.Response.Cookies.Add(authCookie);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError("", "Usuario y/o contraseña incorrecto(s).");
                }
            }

            // Si llegamos a este punto, es que se ha producido un error y volvemos a mostrar el formulario
            return View(model);
        }

        // POST: /Account/LogOff
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            //AuthenticationManager.SignOut();
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

        
    }
}