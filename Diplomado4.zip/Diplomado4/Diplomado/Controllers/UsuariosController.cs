﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using Diplomado.Models;

namespace Diplomado.Controllers
{
    [Authorize(Roles="admin")]
    
    public class UsuariosController : Controller
    {
        Datos db = new Datos();

        // GET: Usuarios
        public ActionResult Index()
        {
            List<UsuarioSeguridad> usuarios = db.TablaUsuarios.ToList();
            return View(usuarios);
        }

        // GET: Usuarios/Details/5
        public ActionResult Details(int id)
        {
            UsuarioSeguridad usuario = db.TablaUsuarios.Find(id);
            return View(usuario);
        }

        // GET: Usuarios/Create
        public ActionResult Create()
        {
            UsuarioViewModel viewModel = new UsuarioViewModel();
            viewModel.ListadoRoles = this.ObtenerRoles();
            return View(viewModel);
        }

        // POST: Usuarios/Create
        [HttpPost]
        public ActionResult Create(UsuarioViewModel viewModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    UsuarioSeguridad usuario = new UsuarioSeguridad();
                    usuario.Usuario = viewModel.Usuario;
                    usuario.Nombre = viewModel.Nombre;
                    usuario.Contraseña = viewModel.Contraseña;
                    usuario.Estatus = "A";
                    usuario.Roles = viewModel.Roles;

                    db.TablaUsuarios.Add(usuario);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        // GET: Usuarios/Edit/5
        public ActionResult Edit(int id)
        {
            UsuarioSeguridad usuario = db.TablaUsuarios.Find(id);
            UsuarioViewModel viewModel = new UsuarioViewModel();
            viewModel.Usuario = usuario.Usuario;
            viewModel.Nombre = usuario.Nombre;
            viewModel.Roles = usuario.Roles;
            viewModel.ListadoRoles = this.ObtenerRoles();
            return View(viewModel);
        }

        // POST: Usuarios/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, UsuarioViewModel viewModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    UsuarioSeguridad usuario = db.TablaUsuarios.Find(id);
                    usuario.Usuario = viewModel.Usuario;
                    usuario.Nombre = viewModel.Nombre;
                    usuario.Contraseña = viewModel.Contraseña;
                    usuario.Roles = viewModel.Roles;
                    db.Entry(usuario).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                return View();
            }
            catch
            {
                return View();
            }
        }

        // GET: Usuarios/Delete/5
        public ActionResult Delete(int id)
        {
            UsuarioSeguridad usuario = db.TablaUsuarios.Find(id);
            UsuarioViewModel viewModel = new UsuarioViewModel();
            viewModel.Usuario = usuario.Usuario;
            viewModel.Nombre = usuario.Nombre;
            viewModel.Roles = usuario.Roles;
            viewModel.ListadoRoles = this.ObtenerRoles();
            return View(viewModel);
        }

        // POST: Usuarios/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, UsuarioViewModel viewModel)
        {
            try
            {
                UsuarioSeguridad buscar = db.TablaUsuarios.Find(id);
                db.TablaUsuarios.Remove(buscar);
                db.SaveChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        private List<string> ObtenerRoles()
        {
            List<string> roles = new List<string>();
            roles.Add("admin");
            roles.Add("captura");
            roles.Add("venta");
            return roles;
        }

    }
}
