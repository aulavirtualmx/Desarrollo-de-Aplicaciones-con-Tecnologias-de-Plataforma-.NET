﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using Diplomado.Models;

namespace Diplomado.Controllers
{
   [Authorize(Roles = "admin, venta")]
    public class VentasController : Controller
    {
        Datos db = new Datos();

        // GET: Ventas
        public ActionResult Index()
        {
            return View(db.TablaVentas.ToList());
        }

       
        public ActionResult Create()
        {
            VentaViewModel ventaView = new VentaViewModel();
            ventaView.Clientes = db.TablaClientes.ToList();
            ventaView.Empleados = db.TablaEmpleados.ToList();
            ventaView.Productos = db.TablaProductos.ToList();
            return View(ventaView);
        }

        [HttpPost]
        public ActionResult AgregarProducto(VentaViewModel view)
        {
            view.Clientes = db.TablaClientes.ToList();
            view.Empleados = db.TablaEmpleados.ToList();
            view.Productos = db.TablaProductos.ToList();
            Producto producto = db.TablaProductos.Find(view.IdProdSeleccionado);

            VentaDetalleViewModel buscar = view.Detalle.SingleOrDefault( x=>x.IdProd == producto.IdProd);

            if (buscar == null)
            {
                view.Detalle.Add(new VentaDetalleViewModel() { 
                    IdProd = producto.IdProd, 
                    Cantidad = 1, 
                    PrecioUnitario = producto.PrecioUnit, 
                    Descripcion = producto.Descripcion, 
                    TotalProducto = producto.PrecioUnit });
            }
            else
            {
                buscar.Cantidad++;
                buscar.TotalProducto += buscar.PrecioUnitario;
            }

            view.SubTotal = 0;
            foreach (VentaDetalleViewModel det in view.Detalle)
            {
                view.SubTotal += det.TotalProducto;
            }

            view.IVA = view.SubTotal * .16m;
            view.Total = view.SubTotal + view.IVA;


            ModelState.Clear();

            return View("Create", view);
        }

        

        [HttpPost]
        public ActionResult Guardar(VentaViewModel view)
        {
            Venta venta = new Venta();

            venta.IdCliente = view.IdClienteSeleccionado;
            venta.IdEmp = view.IdEmpSeleccionado;
            venta.Fecha = DateTime.Now;
            venta.Detalle = new List<VentaDetalle>();

            foreach (VentaDetalleViewModel det in view.Detalle)
            {
                venta.Detalle.Add(new VentaDetalle() { 
                    IdProd = det.IdProd, 
                    Cantidad = det.Cantidad, 
                    PrecioVenta = det.PrecioUnitario }
                );
                venta.SubTotal += det.TotalProducto;
            }

            venta.IVA = venta.SubTotal * .16m;
            venta.Total = venta.SubTotal + venta.IVA;

            db.TablaVentas.Add(venta);
            db.SaveChanges();


            return RedirectToAction("Index");
        }
    }
}