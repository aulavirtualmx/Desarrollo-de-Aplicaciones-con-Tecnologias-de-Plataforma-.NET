﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using Diplomado.Models;

namespace Diplomado.Controllers
{

    public class EmpleadosController : Controller
    {
        Datos db = new Datos();

        //
        // GET: /Empleados/
        public ActionResult Index()
        {
            List<Empleado> empleados = db.TablaEmpleados.ToList();
            return View(empleados);
        }

        //
        // GET: /Empleados/Details/5
        public ActionResult Details(int id)
        {
            return View(db.TablaEmpleados.Find(id));
        }

        //
        // GET: /Empleados/Create
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Empleado empleado)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    //Buscar si existe el empleado
                    Empleado buscar = db.TablaEmpleados.Find(empleado.IdEmp);
                    if (buscar == null) //Si no lo encuentra en la bd
                    {
                        //Guardar en base de datos
                        db.TablaEmpleados.Add(empleado);
                        db.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewBag.error = "Error, al guardar el registro. ID duplicado";
                    }
                }

                return View();

            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Empleados/Edit/5
        public ActionResult Edit(int id)
        {
            return View(db.TablaEmpleados.Find(id));
        }

        //
        // POST: /Empleados/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Empleado empleado)
        {
            try
            {
                // TODO: Add update logic here
                if (ModelState.IsValid)
                {
                    db.Entry(empleado).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Empleados/Delete/5
        public ActionResult Delete(int id)
        {
            return View(db.TablaEmpleados.Find(id));
        }

        //
        // POST: /Empleados/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, Empleado empleado)
        {
            try
            {
                // Eliminar en la base de datos
                Empleado buscar = db.TablaEmpleados.Find(id);
                db.TablaEmpleados.Remove(buscar);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
