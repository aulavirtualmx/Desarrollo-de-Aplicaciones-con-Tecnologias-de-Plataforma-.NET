﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

using System.ComponentModel.DataAnnotations.Schema;

namespace Diplomado.Models
{
    [Table("Clientes")]
    public class Cliente
    {
     
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Range(100, 9999, 
            ErrorMessage="Debe proporcionar un número entre 100 y 9999")]
        [DisplayName("ID")]
        public int IdCliente { get; set; }
        [DisplayName("Nombre")]
        [Required(ErrorMessage="Debe proporcionar un nombre")]
        [StringLength(50, MinimumLength=7, 
            ErrorMessage="Debe de proporcionar al menos 7 letras y máximo 50 letras")]
        public string NomCliente { get; set; }
        [DisplayName("Domicilio")]
        [Required(ErrorMessage = "Debe proporcionar un domicilio")]
        [StringLength(100, MinimumLength = 10,
            ErrorMessage = "Debe de proporcionar al menos 10 caracteres y máximo 100 caracteres")]
        public string DomCliente { get; set; }
        [DisplayName("Teléfono")]
        [Required(ErrorMessage = "Debe proporcionar un teléfono")]

        [RegularExpression(@"^(\d{10})$",
            ErrorMessage="Formato de teléfono incorrecto")]

        public string TelCliente { get; set; }

        [DisplayName("Correo")]
        [Required(ErrorMessage="Debe proporcionar un correo")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "El formato del correo electrónico es incorrecto")]
        public string EmailCliente { get; set; }

        [DisplayName("Fecha de Nacimiento")]
        [Required(ErrorMessage="Debe proporcionar una fecha de nacimiento")]
        [DataType( System.ComponentModel.DataAnnotations.DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime FechaNacCliente { get; set; }

        [NotMapped]
        public string FechaFormato
        {
            get
            {
                return this.FechaNacCliente.ToShortDateString();
            }
        }

        //Constructor
        public Cliente(int id, string nom, string dom, string tel, string correo, DateTime fecha)
        {
            this.IdCliente = id;
            this.NomCliente = nom;
            this.DomCliente = dom;
            this.TelCliente = tel;
            this.EmailCliente = correo;
            this.FechaNacCliente = fecha;
        }

        public Cliente()
        {

        }

    }
}