﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Diplomado.Models
{
    [Table("Ventas")]
    public class Venta
    {
        [Key]
        public int NumVenta { get; set; }
        public DateTime Fecha { get; set; }
        public decimal SubTotal { get; set; }
        public decimal IVA { get; set; }
        public decimal Total { get; set; }
        public int IdCliente { get; set; }

        [ForeignKey("IdCliente")]
        public virtual Cliente Cliente { get; set; }
        public int IdEmp { get; set; }
        [ForeignKey("IdEmp")]
        public virtual Empleado Empleado { get; set; }
        public virtual List<VentaDetalle> Detalle { get; set; }
    }
}