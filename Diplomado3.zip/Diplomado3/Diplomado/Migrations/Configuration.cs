namespace Diplomado.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using Diplomado.Models;
    internal sealed class Configuration : DbMigrationsConfiguration<Diplomado.Models.Datos>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
        }

        protected override void Seed(Diplomado.Models.Datos context)
        {
            
             
            context.TablaClientes.Add(
                    new Cliente(123, "Jos� Lopez", "Conocido 1", "6677112233", "jose@correo.com", new DateTime(2017,1,1))
                );

            context.TablaClientes.Add(
                    new Cliente(124, "Mar�a Soto", "Conocido 2", "6677112244", "maria@correo.com", new DateTime(2017, 1, 1))
                );

            context.TablaClientes.Add(
                    new Cliente(125, "Jes�s Hernandez", "Conocido 3", "6677112255", "jesus@correo.com", new DateTime(2017, 1, 1))
                );

            context.TablaClientes.Add(
                    new Cliente(126, "Lucia Santos", "Conocido 4", "6677112266", "lucia@correo.com", new DateTime(2017, 1, 1))
                );
             

          
        }
    }
}
